<?php

require_once "Shape.php";

class Rectangle extends Shape
{
    
    const SHAPE_TYPE = 2;
    
}

?>